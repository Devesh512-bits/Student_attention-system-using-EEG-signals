// Handle tab switching
document.querySelectorAll('.tab-link').forEach(button => {
    button.addEventListener('click', () => {
        const tabId = button.getAttribute('data-tab');

        // Remove active class from all tabs
        document.querySelectorAll('.tab-link').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(content => content.style.display = 'none');

        // Activate the selected tab
        button.classList.add('active');
        document.getElementById(tabId).style.display = 'block';
    });
});

// Handle graph toggling
const toggleButton = document.getElementById('toggle-graph');
const graphContainer = document.getElementById('graph-container');

if (toggleButton) {
    toggleButton.addEventListener('click', () => {
        const isVisible = graphContainer.style.display === 'block';
        graphContainer.style.display = isVisible ? 'none' : 'block';

        if (!isVisible) {
            drawGraph();
        }
    });
}

// Draw a simple graph
function drawGraph() {
    const ctx = document.getElementById('eeg-graph').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['1s', '2s', '3s', '4s', '5s'],
            datasets: [{
                label: 'EEG Signal',
                data: [4, 1, 2, 3, 5],
                borderColor: '#4285F4',
                fill: false
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                }
            }
        }
    });
}
